<?php

namespace App\Models;

use CodeIgniter\Model;

class MahasiswaModel extends Model
{
    protected $nama = "Hani";
    protected $foto1 = "Foto1.jpg";

    public function getNama()
    {
        return $this->nama;
    }

    public function getFoto1()
    {
        return $this->foto1;
    }
}
