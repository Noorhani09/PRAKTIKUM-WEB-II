<?php
$imageURL = "https://i.postimg.cc/gkbbGDmY/IMG-9974.jpg";

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <Style>
        .buttons {
            display: flex;
            justify-content: space-around;
            top: 20px;
            left: 20px;
        }

        .buttons button {
            width: 150px;
            height: 20px;
            background-color: white;
            margin: 20px;
            color: #568fa6;
            position: relative;
            overflow: hidden;
            font-size: 14px;
            letter-spacing: 1px;
            font-weight: 500;
            text-transform: uppercase;
            transition: all 0.3s ease;
            cursor: pointer;
            border: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 3px;
        }

        .buttons button:before,
        .buttons button:after {
            content: "";
            position: absolute;
            width: 0;
            height: 2px;
            background-color: #44d8a4;
            transition: all 0.3s cubic-bezier(0.35, 0.1, 0.25, 1);
        }

        .buttons button:before {
            right: 0;
            top: 0;
            transition: all 0.5s cubic-bezier(0.35, 0.1, 0.25, 1);
        }

 

        .buttons button span {
            width: 100%;
            height: 100%;
            position: absolute;
            left: 0;
            top: 0;
            margin: 0;
            padding: 0;
            z-index: 1;
        }

        .buttons button span:before,
        .buttons button span:after {
            content: "";
            position: absolute;
            width: 2px;
            height: 0;
            background-color: #212A3E;
            transition: all 0.3s cubic-bezier(0.35, 0.1, 0.25, 1);
        }

        .buttons button span:before {
            right: 0;
            top: 0;
            transition: all 0.5s cubic-bezier(0.35, 0.1, 0.25, 1);
        }

   
        .buttons button p {
            padding: 0;
            margin: 0;
            transition: all 0.4s cubic-bezier(0.35, 0.1, 0.25, 1);
            position: absolute;
            width: 100%;
            height: 100%;
        }

        .buttons button p:before,


        .buttons button p:before {
            content: attr(data-title);
            top: 50%;
            transform: translateY(-50%);
        }

 

        .buttons button:hover:before,
  
        .buttons button:hover span {
            z-index: 1;
        }

        .buttons button:hover span:before,
 

        .buttons button:hover p:before {
            top: -50%;
            transform: rotate(5deg);
        }


        .buttons button.start {
            background-color: #44d8a4;
            box-shadow: 0px 5px 10px -10px rgba(0, 0, 0, 0.2);
            transition: all 0.2s ease;
        }

        .buttons button.start p:before {
            top: -50%;
            transform: rotate(5deg);
        }

 

        @keyframes start {
            from {
                top: -50%;
            }
        }

        .buttons button.start:hover:before,
   

        .buttons button.start:hover span {
            display: none;
        }

        .buttons button:active {
            outline: none;
            border: none;
        }

        .buttons button:focus {
            outline: 0;
        }

        .card-client {
            background: #394867;
            width: 25rem;
            padding-top: 25px;
            padding-bottom: 25px;
            padding-left: 20px;
            padding-right: 20px;
            border: 4px solid #526D82;
            box-shadow: 0 6px 10px rgba(207, 212, 222, 1);
            border-radius: 10px;
            text-align: center;
            color: #fff;
            font-family: "Poppins", sans-serif;
            transition: all 0.3s ease;
        }

        .card-client:hover {
            transform: translateY(-10px);
        }

        .user-picture {
            overflow: hidden;
            object-fit: cover;
            width: 8rem;
            height: rem;
            border: 4px solid #526D82;
            border-radius: 999px;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: auto;
        }

        .user-picture svg {
            width: 2.5rem;
            fill: currentColor;
        }

        .name-client {
            margin: 0;
            margin-top: 20px;
            font-weight: 600;
            font-size: 18px;
        }

        .name-client span {
            display: block;
            font-weight: 200;
            font-size: 16px;
        }

        .social-media:before {
            content: " ";
            display: block;
            width: 100%;
            height: 2px;
            margin: 20px 0;
            background: #526D82;
        }

        .social-media a {
            position: relative;
            margin-right: 15px;
            text-decoration: none;
            color: inherit;
        }

        .social-media a:last-child {
            margin-right: 0;
        }

        .social-media a svg {
            width: 1.1rem;
            fill: currentColor;
        }

        /*-- Tooltip Social Media --*/
        .tooltip-social {
            background: #262626;
            display: block;
            position: absolute;
            bottom: 0;
            left: 50%;
            padding: 0.5rem 0.4rem;
            border-radius: 5px;
            font-size: 0.8rem;
            font-weight: 600;
            opacity: 0;
            pointer-events: none;
            transform: translate(-50%, -90%);
            transition: all 0.2s ease;
            z-index: 1;
        }

        .tooltip-social:after {
            content: " ";
            position: absolute;
            bottom: 1px;
            left: 50%;
            border: solid;
            border-width: 10px 10px 0 10px;
            border-color: transparent;
            transform: translate(-50%, 100%);
        }

        .social-media a .tooltip-social:after {
            border-top-color: #262626;
        }

        .social-media a:hover .tooltip-social {
            opacity: 1;
            transform: translate(-50%, -130%);
        }
    </Style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>

    <div class="card-client mx-auto mt-5">
        <div class="user-picture">
            <div>
                <img src="<?php echo $imageURL; ?>" alt="Gambar" class="img-fluid rounded-start" alt="...">
            </div>
        </div>
        <p class="name-client"> Noorhani
            <span>Mahasiswi Teknologi Informasi
            </span>
        </p>
        <form action="/home/biodata">
        <div class="buttons">
            <button class="btn" type="submit">
                <span></span>
                <p data-title="More"></p>
            </button>
        </div>
    </form>
       
    </div>
 


</body>

</html>